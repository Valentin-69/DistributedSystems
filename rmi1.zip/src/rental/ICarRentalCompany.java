package rental;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.List;
import java.util.Set;

public interface ICarRentalCompany extends Remote {

	Set<CarType> getAvailableCarTypes(Date start, Date end) throws RemoteException;
	
	Quote createQuote(ReservationConstraints constraints, String client) throws RemoteException, ReservationException;
	
	Reservation confirmQuote(Quote quote) throws RemoteException, ReservationException;
	
	List<Reservation> getReservationsByRenter(String clientName) throws RemoteException;
	
	int getNumberOfReservationsForCarType(String carType) throws RemoteException;
}
